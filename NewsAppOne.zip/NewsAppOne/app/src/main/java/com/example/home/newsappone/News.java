package com.example.home.newsappone;

/**
 * Created by Home on 12/19/2017.
 */

public class News {
    private String sectionName;
    private String webPublicationDate;
    private String webTitle;
    private String webUrl;

    public News(String msectionname,
                String mwebpublicationdate,
                String mwebtitle,
                String mweburl) {
        sectionName = msectionname;
        webPublicationDate = mwebpublicationdate;
        webTitle = mwebtitle;
        webUrl = mweburl;
    }

    public String getSectionName() {
        return sectionName;
    }

    public String getWebPublicationDate() {
        return webPublicationDate;
    }

    public String getWebTitle() {
        return webTitle;
    }

    public String getWebUrl() {
        return webUrl;
    }


}
